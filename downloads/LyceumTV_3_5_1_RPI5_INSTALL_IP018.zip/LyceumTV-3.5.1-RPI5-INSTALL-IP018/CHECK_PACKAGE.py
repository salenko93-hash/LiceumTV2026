"""Validate this installation package; requires only Python 3.10+ stdlib."""
from pathlib import Path
import sys
sys.dont_write_bytecode = True

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root / "server"))
from update_transaction import validate_release

try:
    version = validate_release(root)
except (OSError, ValueError, SyntaxError, KeyError) as error:
    print("PACKAGE CHECK FAILED:", error)
    raise SystemExit(1)
print("PACKAGE CHECK PASSED: LyceumTV", version)
