param(
    [string]$PiHost = "192.168.0.18",
    [string]$PiUser = "admin"
)

$ErrorActionPreference = "Stop"
$target = "${PiUser}@${PiHost}"

if (-not (Get-Command ssh -ErrorAction SilentlyContinue)) {
    throw "ssh not found. Install Windows OpenSSH Client."
}

Write-Host "Checking Raspberry Pi: $target"
Write-Host ""

& ssh $target @'
set +e
echo "=== API ==="
curl -fsS http://127.0.0.1:8080/api/health
echo
echo
echo "=== SERVICES ==="
for s in lyceumtv.service lyceumtv-kiosk.service lyceumtv-watchdog.timer; do
  printf "%-28s " "$s"
  systemctl is-active "$s"
done
echo
echo "=== BOOT TARGET ==="
systemctl get-default
echo
echo "=== DISPLAY MODES ==="
for f in /sys/class/drm/*HDMI*/modes; do
  [ -f "$f" ] || continue
  echo "-- $f"
  head -n 8 "$f"
done
echo
echo "=== KIOSK LOG TAIL ==="
journalctl -u lyceumtv-kiosk.service -n 20 --no-pager || true
'@

if ($LASTEXITCODE -ne 0) {
    Write-Warning "One or more remote checks returned a non-zero exit code."
}

Write-Host ""
Write-Host "TV:       http://${PiHost}:8080/"
Write-Host "Admin:    http://${PiHost}:8080/admin"
Write-Host "Ops:      http://${PiHost}:8080/ops"
Write-Host "UI debug: http://${PiHost}:8080/?debug=1"
Write-Host "Mobile:   http://${PiHost}:8080/mobile/"
