param([string]$PiHost = "192.168.0.18")
Start-Process "http://${PiHost}:8080/admin"
