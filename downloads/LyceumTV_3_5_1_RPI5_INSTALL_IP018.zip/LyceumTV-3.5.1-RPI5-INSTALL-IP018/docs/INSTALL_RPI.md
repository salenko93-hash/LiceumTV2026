# Встановлення на Raspberry Pi 5

Потрібна Raspberry Pi OS 64-bit, мережа, HDMI-екран і SSH. Зарезервуйте IP-адресу `192.168.0.18` в DHCP. Пакет очікує цю адресу, але не призначає її мережевому інтерфейсу Pi.
Рекомендований шлях із Windows наведено в README.md (`INSTALL_TO_RPI5.ps1`).

Для локального встановлення на Pi від звичайного користувача із sudo:

```bash
chmod +x scripts/*.sh
./scripts/install.sh
```

Installer встановлює Python/openpyxl/qrcode, curl, rsync, Cage та Chromium, копіює застосунок у `/opt/lyceumtv`, створює systemd-служби та таймери.
Наступний запуск використовує Cage kiosk і multi-user.target. Налаштовувати Desktop Autologin не потрібно.
Перевірте `/api/health` та `sudo systemctl status lyceumtv lyceumtv-kiosk`.
`CHECK_RPI.ps1` збирає діагностику через SSH; це не заміна огляду реального HDMI-екрана та перевірки аудіо.
