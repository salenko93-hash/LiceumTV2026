#!/usr/bin/env bash
set -u

APP_URL="${LYCEUMTV_URL:-http://127.0.0.1:8080/api/health}"
DEVTOOLS_URL="http://127.0.0.1:9222/json/version"
ROOT="/opt/lyceumtv"
COUNT_FILE="/run/lyceumtv-watchdog-failcount"
OTA_PENDING="$ROOT/data/ota_pending"

# A supervisor/worker owns the whole update, health verification and rollback.
if [[ -f "$OTA_PENDING" ]]; then
  if python3 "$ROOT/launcher.py" --root "$ROOT" --update-active; then
    exit 0
  fi
  logger -t lyceumtv-watchdog "Interrupted/stalled update; restarting supervisor for recovery"
  systemctl restart lyceumtv.service || true
  exit 0
fi

if curl -fsS --max-time 5 "$APP_URL" >/dev/null; then
  echo 0 >"$COUNT_FILE" 2>/dev/null || true
else
  logger -t lyceumtv-watchdog "HTTP health failed; restarting lyceumtv supervisor"
  systemctl restart lyceumtv.service || true
fi

if ! curl -fsS --max-time 5 "$DEVTOOLS_URL" >/dev/null; then
  logger -t lyceumtv-watchdog "Chromium check failed; restarting lyceumtv-kiosk.service"
  systemctl restart lyceumtv-kiosk.service || true
fi

# 3.5.1 startup/display probe; never restart a healthy application solely for display failure.
if command -v curl >/dev/null 2>&1; then
  curl -fsS --connect-timeout 2 --max-time 5 http://127.0.0.1:8080/ >/dev/null 2>&1 || logger -t lyceumtv-watchdog 'Display HTML unavailable'
  curl -fsS --connect-timeout 2 --max-time 5 http://127.0.0.1:8080/js/app.js >/dev/null 2>&1 || logger -t lyceumtv-watchdog 'Display JavaScript unavailable'
fi
